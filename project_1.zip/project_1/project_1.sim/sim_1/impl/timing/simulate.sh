#!/bin/bash -f
xv_path="/opt/Xilinx/Vivado/2016.4"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim base_time_impl -key {Post-Implementation:sim_1:Timing:base} -tclbatch base.tcl -view /home/ped/project_1/base_behav.wcfg -log simulate.log
