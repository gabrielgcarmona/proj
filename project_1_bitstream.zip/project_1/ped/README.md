Trabalho de PED para c�lculo num�rico de polin�mios
----------------------------------------------------------------------------------------------------------------------------------
_________________________________________________________________
1) Cadastrar grau de polin�mio,apertar enter,aparecer ok, cadastrar polin�mio,apertar enter,aparecer ok para cada coeficiente do polin�mio,quando terminar aparecer okP,cadastrar valor de x, aparecer valor num�rico e chave para ver a derivada. 

2) 

Como usar multiplexador de displays:
----------------------------------------------------------------
	Existem 4 entradas no multiplexador: a,b,c,d cada uma representa um display sendo d o display mais a esquerda. Essas entradas sao numeros binarios de 5 bits com cada valor representando um numero ou letra, o bit mais significativo troca entre numeros e letras segundo a tabela:

Codigo | Numero
:---: | :---:
"00000" | 0 
"00001" | 1 
"00010" | 2
"00011" | 3
"00100" | 4
"00101" | 5
"00110" | 6
"00111" | 7
"01000" | 8
"01001" | 9
"01010" | **Desliga display**
"01011" | **Desliga display**
"01100" | **Desliga display**
"01101" | **Desliga display**
"01110" | **Desliga display**
"01111" | **Desliga display**
"10000" | A
"10001" | d
"10010" | k
"10011" | m
"10100" | o
"10101" | P
"10110" | r
"10111" | u
"11000" | -
